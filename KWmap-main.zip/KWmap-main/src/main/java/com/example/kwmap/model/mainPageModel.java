package com.example.kwmap.model;

import lombok.Data;

@Data
public class mainPageModel {
    private int id;
    private String bd_name;
    private String floor;
    private String fc_name;
}
