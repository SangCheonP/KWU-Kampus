package com.example.kwmap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KWmapApplication {

    public static void main(String[] args) {
        SpringApplication.run(KWmapApplication.class, args);
    }

}
