package com.example.kwmap.model;

import lombok.Data;

@Data
public class SampleModel {
    private int id;
}
